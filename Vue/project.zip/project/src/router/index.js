import Vue from 'vue'
import Router from 'vue-router'

// import HelloWorld from '@/components/HelloWorld'

import Home from '@/components/Home'
import Code from '@/components/Code'
import Music from '@/components/Music'
import Video from '@/components/Video'
import About from '@/components/About'
import Service from '@/components/Service'
import GuestBook from '@/components/GuestBook'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      components: { Home },
    },
    {
      path: '/link',
      components: { Code },
    },
    {
      path: '/think',
      components: { Code }
    },
    {
      path: '/music',
      components: { Music }
    },
    {
      path: '/vlog',
      components: { Video }
    },
    {
      path: '/about',
      components: { About }
    },
    {
      path: '/service',
      components: { Service }
    },
    {
      path: '/guestbook',
      components: { GuestBook }
    },
    {//重定向路由
      path: '*',
      redirect: '/'
    }
  ]
})
