<template>
    <div id="cate">
        <nav class="nav clearfix">
            <li class="nav_list active">
                <router-link class="linkto link_active" to="index">明殿</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/link">宁静寺</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/think">无色庵</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="www.baidu.com">丹青阁</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/music">粉巷</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/vlog">天涯</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/pic">海角</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/about">狂浪生</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/service">得道</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto" to="/guestbook">四方馆</router-link>
            </li>
            <li class="nav_list">
                <router-link class="linkto exp" to="www.jypc.org">云上爆款</router-link>
            </li>
        </nav>
    </div>
</template>
<script>
export default {
  name: "Categories",
};
</script>
<style scoped>
/* #cate{
    position: relative;
}
.nav{
    position: fixed;
    width: 160px;
} */
.clearfix::after{
    width: 160px;
}
.nav_list{
    text-align: center;
    padding: 10px 0;
    margin-bottom: 10px;
    height: 20px;
    line-height: 20px;
}
.linkto{
    font-size: 15px;
    color: #6e6e85;
    
}
.nav_list:hover .linkto{
    color: #008cf4;
}
.active{
    background-color: #f9f9f9;
}
.link_active{
    color: #008df6;
}
.nav_list exp{
    border-top: 1px dashed #dadada;
}
</style>