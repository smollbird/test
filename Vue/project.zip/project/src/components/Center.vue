<template>
  <div id="center">
    <router-view name="link"></router-view>
    <!-- <ArticlesHeader></ArticlesHeader>
    <Content v-for="num in 10" :key="num"></Content> -->
  </div>
</template>
<script>
// import Content from "@/components/Content";
// import ArticlesHeader from "@/components/ArticlesHeader";
export default {
  name: "Center",
  // components: { Content, ArticlesHeader },
};
</script>
<style scoped>
</style>