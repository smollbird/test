<template>
  <div class="banner">
    <div class="img_item">
      <img src="#" alt="1" class="item" />
      <img src="#" alt="2" class="item" />
      <img src="#" alt="3" class="item" />
      <img src="#" alt="4" class="item" />
    </div>
    <div class="dot">
      <ul class="dot_item">
        <li class="quiet"></li>
        <li class="quiet"></li>
        <li class="quiet"></li>
        <li class="quiet"></li>
      </ul>
    </div>
  </div>
</template>
<script>

export default {
  name: "Banner",
};
</script>
<style scoped>
</style>