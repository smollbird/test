<template>
  <div id="main">
    <div class="container clearfix">
      
      <Aside class="aside"></Aside>
      <Center class="body"></Center>
    </div>
  </div>
</template> 
<script>
import Cate from "@/components/Categories";
import Center from "@/components/Center";
import Aside from "@/components/Aside";

export default {
  name: "Main",
  components: {
    Cate,
    Center,
    Aside,
  },
};
</script>
<style scoped>
#main {
  margin-top: 10px;
}
.clearfix::after {
  height: 0;
}
.cate {
  float: left;
  width: 160px;
  margin-right: 15px;
}
.body {
  margin-left: 167px;
  width: 580px;
}
.aside {
  float: right;
  width: 260px;
  margin-left: 15px;
}
</style>